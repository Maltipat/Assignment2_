# Edge Cases Considered

- Overlapping leave requests (PENDING/APPROVED) on same dates
- Start date after end date
- Zero working days (weekend-only range)
- Insufficient balance (and policy allowing/disallowing negative)
- Applying for past dates vs policy (allow/deny)
- Joining date after requested start date
- Employee INACTIVE
- Large ranges crossing years (split by policy year or deny)
- Concurrent approvals (race conditions) → solved via DB transaction/row lock
- Email uniqueness + department code uniqueness
- Cancelled leave after approval (refund days) – can be implemented via `CANCEL` transaction
