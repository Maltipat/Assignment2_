# ER Diagram (Mermaid) + Notes

```mermaid
erDiagram
    DEPARTMENTS ||--o{ EMPLOYEES : has
    EMPLOYEES ||--o{ LEAVE_REQUESTS : requests
    LEAVE_TYPES ||--o{ LEAVE_POLICIES : defines
    EMPLOYEES ||--o{ LEAVE_BALANCES : holds
    LEAVE_TYPES ||--o{ LEAVE_BALANCES : of_type
    LEAVE_REQUESTS ||--o{ LEAVE_TRANSACTIONS : logs
    LEAVE_TYPES ||--o{ LEAVE_REQUESTS : of_type

    DEPARTMENTS {
      int id PK
      varchar name UK
      varchar code UK
      datetime created_at
      datetime updated_at
    }

    EMPLOYEES {
      int id PK
      varchar name
      varchar email UK
      int department_id FK
      date joining_date
      enum status
      datetime created_at
      datetime updated_at
    }

    LEAVE_TYPES {
      int id PK
      varchar code UK  // e.g., ANNUAL, SICK
      varchar name
      tinyint allow_negative_default
      datetime created_at
      datetime updated_at
    }

    LEAVE_POLICIES {
      int id PK
      int leave_type_id FK
      int yearly_entitlement
      tinyint carry_forward_allowed
      int carry_forward_cap
      datetime created_at
      datetime updated_at
    }

    LEAVE_BALANCES {
      int id PK
      int employee_id FK
      int leave_type_id FK
      decimal opening_balance
      decimal accrued
      decimal consumed
      decimal remaining
      year policy_year
      datetime created_at
      datetime updated_at
      UNIQUE employee_year_type (employee_id, policy_year, leave_type_id)
    }

    LEAVE_REQUESTS {
      int id PK
      int employee_id FK
      int leave_type_id FK
      date start_date
      date end_date
      int days
      enum status // PENDING, APPROVED, REJECTED, CANCELLED
      text reason
      int decided_by_employee_id FK
      datetime decided_at
      datetime created_at
      datetime updated_at
    }

    LEAVE_TRANSACTIONS {
      int id PK
      int leave_request_id FK
      int employee_id FK
      int leave_type_id FK
      enum action // APPLY, APPROVE, REJECT, CANCEL, ADJUST
      decimal delta_days
      text notes
      datetime created_at
    }
```

## Notes
- `LEAVE_BALANCES.remaining = opening_balance + accrued - consumed` (maintained with triggers or service logic)
- `days` excludes weekends by business rule (see pseudocode)
- Indexes added on FK columns and frequently queried fields
