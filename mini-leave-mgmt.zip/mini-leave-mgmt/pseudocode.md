# Leave Approval Logic (Pseudocode)

```
function businessDays(startDate, endDate):
    days = 0
    for d in eachDateInclusive(startDate, endDate):
        if d is Saturday or Sunday: continue
        days += 1
    return days

function hasOverlap(employeeId, startDate, endDate):
    return exists APPROVED or PENDING leave_request
           where employee_id = employeeId
             and date_range overlaps (startDate..endDate)

function canConsumeBalance(employeeId, leaveTypeId, year, daysRequested):
    balance = find LEAVE_BALANCES by (employeeId, leaveTypeId, year)
    if not balance: return false, "No balance record"
    remaining = balance.opening_balance + balance.accrued - balance.consumed
    policy = find LEAVE_POLICIES by leaveTypeId
    if remaining >= daysRequested: return true, null
    if policy.allow_negative_default: return true, null
    return false, "Insufficient balance"

function applyLeave(input):
    assert dates valid (start <= end)
    assert employee ACTIVE
    assert leaveType exists

    if hasOverlap(input.employeeId, input.startDate, input.endDate):
        return error "Overlapping leave"

    days = businessDays(input.startDate, input.endDate)
    if days == 0: return error "No working days"

    ok, msg = canConsumeBalance(input.employeeId, input.leaveTypeId, year(input.startDate), days)
    if not ok: return error msg

    create leave_request with status PENDING, days = days
    create leave_transaction(action=APPLY, delta_days=0)

    return success (id)

function approveLeave(id, approverId):
    lr = find leave_request by id
    if lr.status != PENDING: return error "Invalid state"

    begin transaction
        update leave_request set status=APPROVED, decided_by=approverId, decided_at=now()
        update leave_balances set consumed = consumed + lr.days where employee_id=lr.employee_id and leave_type_id=lr.leave_type_id and policy_year=year(lr.start_date)
        insert leave_transaction(action=APPROVE, delta_days = -lr.days)
    commit
    return success

function rejectLeave(id, approverId, reason):
    lr = find leave_request by id
    if lr.status != PENDING: return error "Invalid state"

    begin transaction
        update leave_request set status=REJECTED, decided_by=approverId, decided_at=now(), reason = concat(lr.reason, " | Rej: ", reason)
        insert leave_transaction(action=REJECT, delta_days = 0)
    commit
    return success
```
