
-- MySQL 8+ schema

CREATE TABLE departments (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  code VARCHAR(20) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_dept_name (name),
  UNIQUE KEY uq_dept_code (code)
);

CREATE TABLE employees (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(150) NOT NULL,
  department_id INT NOT NULL,
  joining_date DATE NOT NULL,
  status ENUM('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_emp_email (email),
  KEY idx_emp_department (department_id),
  CONSTRAINT fk_emp_department FOREIGN KEY (department_id) REFERENCES departments(id)
);

CREATE TABLE leave_types (
  id INT PRIMARY KEY AUTO_INCREMENT,
  code VARCHAR(30) NOT NULL,
  name VARCHAR(100) NOT NULL,
  allow_negative_default TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_leave_type_code (code)
);

CREATE TABLE leave_policies (
  id INT PRIMARY KEY AUTO_INCREMENT,
  leave_type_id INT NOT NULL,
  yearly_entitlement INT NOT NULL,
  carry_forward_allowed TINYINT(1) NOT NULL DEFAULT 0,
  carry_forward_cap INT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_policy_type (leave_type_id),
  CONSTRAINT fk_policy_type FOREIGN KEY (leave_type_id) REFERENCES leave_types(id)
);

CREATE TABLE leave_balances (
  id INT PRIMARY KEY AUTO_INCREMENT,
  employee_id INT NOT NULL,
  leave_type_id INT NOT NULL,
  opening_balance DECIMAL(5,2) NOT NULL DEFAULT 0,
  accrued DECIMAL(5,2) NOT NULL DEFAULT 0,
  consumed DECIMAL(5,2) NOT NULL DEFAULT 0,
  remaining DECIMAL(5,2) AS (opening_balance + accrued - consumed) STORED,
  policy_year YEAR NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_emp_year_type (employee_id, policy_year, leave_type_id),
  KEY idx_balance_emp (employee_id),
  KEY idx_balance_type (leave_type_id),
  CONSTRAINT fk_balance_emp FOREIGN KEY (employee_id) REFERENCES employees(id),
  CONSTRAINT fk_balance_type FOREIGN KEY (leave_type_id) REFERENCES leave_types(id)
);

CREATE TABLE leave_requests (
  id INT PRIMARY KEY AUTO_INCREMENT,
  employee_id INT NOT NULL,
  leave_type_id INT NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  days INT NOT NULL,
  status ENUM('PENDING','APPROVED','REJECTED','CANCELLED') NOT NULL DEFAULT 'PENDING',
  reason TEXT NULL,
  decided_by_employee_id INT NULL,
  decided_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_lr_emp (employee_id),
  KEY idx_lr_type (leave_type_id),
  KEY idx_lr_status (status),
  CONSTRAINT fk_lr_emp FOREIGN KEY (employee_id) REFERENCES employees(id),
  CONSTRAINT fk_lr_type FOREIGN KEY (leave_type_id) REFERENCES leave_types(id),
  CONSTRAINT fk_lr_decider FOREIGN KEY (decided_by_employee_id) REFERENCES employees(id),
  CONSTRAINT chk_dates CHECK (start_date <= end_date)
);

CREATE TABLE leave_transactions (
  id INT PRIMARY KEY AUTO_INCREMENT,
  leave_request_id INT NOT NULL,
  employee_id INT NOT NULL,
  leave_type_id INT NOT NULL,
  action ENUM('APPLY','APPROVE','REJECT','CANCEL','ADJUST') NOT NULL,
  delta_days DECIMAL(5,2) NOT NULL DEFAULT 0, -- negative when consuming
  notes TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_lt_req (leave_request_id),
  KEY idx_lt_emp (employee_id),
  CONSTRAINT fk_lt_req FOREIGN KEY (leave_request_id) REFERENCES leave_requests(id),
  CONSTRAINT fk_lt_emp FOREIGN KEY (employee_id) REFERENCES employees(id),
  CONSTRAINT fk_lt_type FOREIGN KEY (leave_type_id) REFERENCES leave_types(id)
);

-- Seed minimal data
INSERT INTO departments (name, code) VALUES ('Human Resources','HR'),('Engineering','ENG'),('Sales','SAL');
INSERT INTO leave_types (code, name) VALUES ('ANNUAL','Annual Leave'),('SICK','Sick Leave');
INSERT INTO leave_policies (leave_type_id, yearly_entitlement, carry_forward_allowed, carry_forward_cap)
VALUES (1, 12, 1, 6), (2, 6, 0, NULL);
