import express from 'express';
import morgan from 'morgan';
import cors from 'cors';

const app = express();
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

// In-memory stores (demo only)
let employees = [];
let leaves = [];
let balances = {}; // key: `${empId}_${type}_${year}` -> {opening:12, accrued:0, consumed:0}

function businessDays(start, end) {
  const s = new Date(start), e = new Date(end);
  let d = new Date(s), days = 0;
  while (d <= e) {
    const wd = d.getDay(); // 0 Sun ... 6 Sat
    if (wd !== 0 && wd !== 6) days++;
    d.setDate(d.getDate() + 1);
  }
  return days;
}

function keyBalance(empId, typeId, year) {
  return `${empId}_${typeId}_${year}`;
}

app.post('/employees', (req, res) => {
  const { name, email, departmentId, joiningDate } = req.body;
  if (!name || !email || !departmentId || !joiningDate) return res.status(400).json({error:'Missing fields'});
  if (employees.find(e => e.email === email)) return res.status(409).json({error:'Email exists'});
  const id = employees.length + 1;
  employees.push({ id, name, email, departmentId, joiningDate, status:'ACTIVE' });
  // Seed balances: Annual(1)->12, Sick(2)->6
  const y = new Date(joiningDate).getFullYear();
  balances[keyBalance(id, 1, y)] = { opening:12, accrued:0, consumed:0 };
  balances[keyBalance(id, 2, y)] = { opening:6, accrued:0, consumed:0 };
  res.status(201).json({ id });
});

app.get('/employees', (req, res) => {
  res.json(employees);
});

app.get('/employees/:id/balances', (req, res) => {
  const id = parseInt(req.params.id);
  const year = parseInt(req.query.year) || new Date().getFullYear();
  const ann = balances[keyBalance(id,1,year)] || {opening:0,accrued:0,consumed:0};
  const sic = balances[keyBalance(id,2,year)] || {opening:0,accrued:0,consumed:0};
  res.json({
    ANNUAL: {...ann, remaining: ann.opening + ann.accrued - ann.consumed},
    SICK: {...sic, remaining: sic.opening + sic.accrued - sic.consumed}
  });
});

app.post('/leaves/apply', (req, res) => {
  const { employeeId, leaveTypeId, startDate, endDate, reason } = req.body;
  if (!employeeId || !leaveTypeId || !startDate || !endDate) return res.status(400).json({error:'Missing fields'});
  const emp = employees.find(e => e.id === employeeId && e.status === 'ACTIVE');
  if (!emp) return res.status(404).json({error:'Employee not found/active'});
  const days = businessDays(startDate, endDate);
  if (days <= 0) return res.status(400).json({error:'No working days'});
  const y = new Date(startDate).getFullYear();
  const key = keyBalance(employeeId, leaveTypeId, y);
  const bal = balances[key] || { opening:0, accrued:0, consumed:0 };
  const remaining = bal.opening + bal.accrued - bal.consumed;
  if (remaining < days) return res.status(422).json({error:'Insufficient balance'});

  const id = leaves.length + 1;
  leaves.push({ id, employeeId, leaveTypeId, startDate, endDate, days, status:'PENDING', reason });
  res.status(201).json({ id, status:'PENDING' });
});

app.post('/leaves/:id/approve', (req, res) => {
  const id = parseInt(req.params.id);
  const lr = leaves.find(l => l.id === id);
  if (!lr || lr.status !== 'PENDING') return res.status(400).json({error:'Invalid request'});
  const y = new Date(lr.startDate).getFullYear();
  const key = keyBalance(lr.employeeId, lr.leaveTypeId, y);
  const bal = balances[key] || { opening:0, accrued:0, consumed:0 };
  balances[key] = { ...bal, consumed: bal.consumed + lr.days };
  lr.status = 'APPROVED';
  res.json({ id, status:'APPROVED' });
});

app.post('/leaves/:id/reject', (req, res) => {
  const id = parseInt(req.params.id);
  const lr = leaves.find(l => l.id === id);
  if (!lr || lr.status !== 'PENDING') return res.status(400).json({error:'Invalid request'});
  lr.status = 'REJECTED';
  res.json({ id, status:'REJECTED' });
});

app.get('/leaves', (req, res) => {
  const { status, employeeId } = req.query;
  let out = [...leaves];
  if (status) out = out.filter(l => l.status === status);
  if (employeeId) out = out.filter(l => l.employeeId === parseInt(employeeId));
  res.json(out);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
